package com.example.myresponsi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainTampil extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_tampil);
    }
}