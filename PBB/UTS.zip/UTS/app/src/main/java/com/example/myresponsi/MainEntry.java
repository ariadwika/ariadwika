package com.example.myresponsi;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class MainEntry extends AppCompatActivity {
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_entry);

        String[] nama_buah ={"Mangga", "Pisang", "Semangka",
                "Salak", "Jeruk", "Apel",
                "Anggur", "Durian"
        };

        int[] gambar_buah ={R.drawable.mangga, R.drawable.pisang, R.drawable.semangka,
                R.drawable.salak, R.drawable.jeruk, R.drawable.apel,
                R.drawable.anggur, R.drawable.durian};

        String[] keterangan ={"Buah mangga mengandung vitamin C yang cukup untuk membantu Anda mencegah serangan bakteri penyebab beragam penyakit seperti sakit pilek hingga flu",
                "Buah pisang merupakan salah satu buah yang kaya akan mineral kalium dan serat pektin.",
                "Buah semangka yang penuh dengan air itu mengandung vitamin A, vitamin B6m dan vitamin C yang signifikan.",
                "Buah salak mengandung nutrisi seperti protein, beta karoten, vitamin C, serat makanan, zat besi, kalsium, fosfor dan karbohidrat yang bagus untuk kesehatan secara keseluruhan.",
                "Buah jeruk sangat identik dengan vitamin C.",
                "Buah apel merupakan buah yang mengandung bahan kimia flavonoids yang memiliki beragam manfaat yang baik untuk tubuh Anda.",
                "Buah anggur memiliki kandungan zat gizi yang baik bagi tubuh.",
                "Buah durian mengandung ragam vitamin dan mineral, karbohidrat, lemak, serta protein."};

        listView=findViewById(R.id.listdatabuah);
        AdapterBuah adapterBuah=new AdapterBuah(this,nama_buah, gambar_buah, keterangan);
        listView.setAdapter(adapterBuah);
        listView.setOnItemClickListener((adapterView, view, position, id) -> {
            String nm_buah= nama_buah[position];
            int gbr_buah=gambar_buah[position];
            String ket= keterangan[position];

            //Toast.makeText(MainActivity.this, ""+gbr_buah, Toast.LENGTH_SHORT).show();
            Intent intent=new Intent(MainEntry.this,DetailBuah.class);
            intent.putExtra("namabuah",nm_buah);
            intent.putExtra("gambarbuah",gbr_buah);
            Intent keter = intent.putExtra("keter", ket);
            startActivity(intent);
        });
    }
}