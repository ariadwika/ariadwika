package com.example.projekaplikasi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class Activity_02 extends AppCompatActivity {
    ImageView imageView;
    TextView mnim, mnama;
    String xnim="nim";
    String xnama="nama";

    String gambar="gambar";
    String nim, nama;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_02);

        imageView=findViewById(R.id.gambarmasuk);
        mnim=findViewById(R.id.nim_mhs);
        mnama=findViewById(R.id.nama_mhs);

        Bundle bundle=getIntent().getExtras();
        nim=bundle.getString(xnim);
        nama=bundle.getString(xnama);

        int tampilgambar=bundle.getInt(gambar);
        mnim.setText(nim);
        mnama.setText(nama);
        imageView.setImageResource(tampilgambar);

    }
}