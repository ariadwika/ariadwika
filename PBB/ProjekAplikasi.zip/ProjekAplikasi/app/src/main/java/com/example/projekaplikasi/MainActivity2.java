package com.example.projekaplikasi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    TextView namaKirim;
    String name="Nama";
    String namanya;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        namaKirim=findViewById(R.id.namaanda);

        Bundle bundle=getIntent().getExtras();
        namanya=bundle.getString(name);
        namaKirim.setText("Hello, My Friend "+namanya);

    }
}