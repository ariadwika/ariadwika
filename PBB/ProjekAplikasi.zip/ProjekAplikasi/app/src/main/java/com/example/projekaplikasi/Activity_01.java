package com.example.projekaplikasi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class Activity_01 extends AppCompatActivity {
    Button button;
    ImageView imageView;
    EditText mnim, mnama;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_01);

        imageView=findViewById(R.id.gambarku);
        mnim=findViewById(R.id.xnim);
        mnama=findViewById(R.id.xnama);

        button=findViewById(R.id.tombolkrm);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cnim=mnim.getText().toString();
                String cnama=mnama.getText().toString();
                Intent intent=new Intent(Activity_01.this, Activity_02.class);
                intent.putExtra("nim", cnim);
                intent.putExtra("nama", cnama);
                intent.putExtra("gambar", R.drawable.fotoalmetbirucrop);
                startActivity(intent);
            }
        });
    }
}